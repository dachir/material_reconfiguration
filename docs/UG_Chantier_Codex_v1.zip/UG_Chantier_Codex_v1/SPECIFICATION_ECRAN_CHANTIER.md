# Spécification — Écran Chantier Univers Glass

## 1. Objectif

Refondre **l'écran existant Chantier** en VueJS, dans le projet Frappe/ERPNext `mat_reco`, suivant `assets/chantier_reference_validee.png`. L'objectif est la **saisie rapide en continu d'ouvrages**, avec sections à gauche et panneau contextuel Services / Accessoires à droite. Ne pas recréer un deuxième système de devis, de commande ou de fabrication.

## 2. Composition visuelle (référence impérative)

- Thème sombre navy / bleus, finesse des bordures, densité et proportions de l'image.
- En haut : breadcrumb, nom et statut du chantier, barre d'actions (menu complémentaire, Annuler, Enregistrer).
- En-tête **sur deux colonnes**, compact :
  - Gauche : Client, Nom du chantier, Adresse / Lieu, Contact.
  - Droite : Devise, Liste de prix, Date prévue, Date livraison cible, Statut.
  - Numéro du chantier à proximité du titre. Les champs réellement disponibles devront être raccordés aux champs Frappe existants ; ne pas créer aveuglément des champs pour illustrer la maquette.
- Sous l'en-tête : **panneau Sections repliable à gauche** + **grille Ouvrages centrale**.
- Sur activation de l'icône d'affectation d'une ligne, **un drawer droit (non modal)** s'ouvre « Services / Accessoires ». La grille se rétrécit/recompose dans l'espace disponible ; elle ne perd ni données ni sélections.
- Les montants, articles, noms et autres données de l'image sont des exemples.

## 3. Panneau « Sections »

- Ouvert : « Tout le chantier », sections avec compteurs, sélection de section, ajouter (+).
- Fermé : bande étroite avec commande de réouverture ; la grille bénéficie de la largeur gagnée.
- Filtrer les lignes d'ouvrages selon la section, sans perdre les éditions en cours.
- La section est facultative. Une nouvelle ligne créée depuis une section active hérite de celle-ci, modifiable ensuite.
- Actions existantes de récupération/génération des sections : maintenir les capacités existantes si disponibles ; elles peuvent être dans un menu secondaire sans encombrer l'écran.

## 4. Grille « Ouvrages » — saisie continue de style Frappe

### Colonnes, dans l'ordre logique

1. Cases à cocher (sélection multiple, avec sélection globale).
2. **Triangle chevron** pour dérouler la sous-ligne des prestations ; **pas de colonne n° de ligne**.
3. Article (Link / autocomplétion Frappe).
4. Section (Link / contrôle Frappe existant).
5. Dimensions techniques / proposées (utiliser les vrais champs structurés, pas uniquement une chaîne libre).
6. Quantité.
7. Unité.
8. Prix unitaire (selon droits / workflow métier).
9. Montant (calculé selon les règles existantes).
10. Actions de ligne, dont l'icône de gestion des Services / Accessoires, duplication et suppression selon permissions.

### Interaction de saisie

- Cellules directement éditables, sans formulaire ou page complémentaire par défaut.
- Tab / Shift+Tab : déplacement entre champs ; Entrée : validation cohérente avec conventions Frappe et sans soumission prématurée du document.
- « + Ajouter une ligne » visible au pied du tableau ; saisie et ajout/duplication rapides.
- Compact sur une ligne par ouvrage (hors ouverture du chevron).
- Recherche parmi les ouvrages du chantier au-dessus de la grille.
- Hauteur de zone grille maîtrisée et **scroll vertical si dépassement** ; **scroll horizontal si largeur dépassée**, indépendants du défilement général du formulaire.
- Conserver si possible l'en-tête de colonnes fixé en haut de la zone scrollable, et le pied Ajouter / Total accessible.
- Sur filtrage ou ouverture du drawer, préserver état de saisie et position de défilement autant que possible.
- Triangle fermé : prestations masquées ; triangle ouvert : sous-ligne affichant les services/accessoires *déjà affectés* à cet ouvrage, avec détails/quantités/valeurs appropriés.

## 5. Icône de services par ligne : règle de ciblage VALIDÉE

**Il n'y a pas de bouton texte global « Services / Accessoires » dans la grille.** Chaque ligne possède son propre **icon button seul**.

- Zéro ligne cochée + clic sur icône de ligne A → drawer ciblant **uniquement A**.
- Une ou plusieurs lignes cochées + clic sur l'icône de **n'importe quelle** ligne X → drawer ciblant **exactement les lignes cochées**, même si X n'en fait pas partie.
- Le clic sur l'icône **ne coche pas automatiquement** la ligne sur laquelle on a cliqué.
- Les cases cochées demeurent cochées après affectation et fermeture du volet.
- Le drawer indique explicitement le **nombre d'ouvrages ciblés** ; si plusieurs sections sont sélectionnées, le compteur reste exact y compris pour les lignes masquées par le filtre.

Règle technique de référence :

```js
const targetIds = checkedOuvrageIds.length > 0
  ? [...checkedOuvrageIds]
  : [clickedOuvrageId];
```

Ne pas transformer le tableau en sélection par clic de ligne. **Case cochée et chevron sont des actions distinctes.**

## 6. Drawer droit « Services / Accessoires »

- Panneau coulissant depuis la droite, dans la page, avec bouton X de fermeture. **Pas de modale centrale**.
- En-tête titre, sous-titre affectation, résumé de la cible (un ou N ouvrages, avec identité d'ouvrage si cible unique).
- Recherche par libellé/code ; filtre « Tous / Services / Accessoires ».
- Liste scrollable à cases à cocher ; chaque ligne présente le nom, la catégorie et, si disponible, le prix/unité cohérents avec le système.
- Sélection de plusieurs prestations à la fois, compteur bas de volet, commande principale « Affecter aux ouvrages sélectionnés » (libellé adapté au singulier si nécessaire).
- Affectation répercutée sur toutes les cibles ; les valeurs déjà présentes ne sont **pas dupliquées** sans raison métier. Vérifier si des répétitions configurées sont licites dans le modèle.
- Respecter les mécanismes existants de calcul des quantités par unité, surface, périmètre ou mode manuel.
- Fermer le drawer sans enregistrer l'affectation ne doit pas faire d'ajouts indésirables ; traiter les modifications locales comme des changements de document non encore persistés si telle est l'architecture existante.
- Après affectation : badges/détails mis à jour, toast discret, sélection d'ouvrages conservée.
- Une liste filtrée n'efface jamais les cases précédemment sélectionnées, sauf action explicite.

## 7. Enregistrement et logique métier

- Frappe/ERPNext est **source de vérité** : préserver DocTypes, Child Tables, validations, permissions, API, statuts, workflows, taxes et tarifs existants.
- Ne pas supposer ni inventer des noms de DocTypes/fields. Faire l'inventaire du dépôt actuel avant de coder ; signaler les manques.
- Le chantier définit les ouvrages ; l'étude technique, le devis, la commande, les révisions et la fabrication conservent leurs workflows distincts.
- Le prix unitaire montré sur la maquette ne justifie pas d'autoriser une modification directe si la politique métier existante ne le permet pas. Tracer les sources du prix et les droits.
- L'addition en pied doit être clairement définie : total chantier, non un total filtré trompeur. Éventuellement afficher sous-total de section séparément.
- Sauvegarde atomique cohérente, validation côté serveur, erreurs sur champs en cause, avertissement si données non sauvées, prévention double-clic et collisions si supportées.
- Ne jamais ajouter de doublons de prestation par simple réaffectation répétée sans valider la logique d'unicité du modèle.

## 8. États UI à implémenter

- Section ouverte / fermée.
- Drawer ouvert / fermé.
- Zéro / une / plusieurs lignes cochées.
- Ligne de détail chevron ouverte / fermée, indépendamment des autres.
- Recherche, filtre de section, filtre et recherche prestations.
- Ouvrage et prestation avec données non enregistrées, chargement, sauvegarde, erreur, succès.
- Grille étroite ou large ; scrollbar verticale/horizontale uniquement si dépassement.

## 9. Performance et accessibilité

- Prévoir plusieurs centaines d'ouvrages ; éviter requête API à chaque frappe et rerender général de toutes les lignes.
- Privilégier identifiants stables et navigation clavier. Préserver le focus durant l'édition et les modifications.
- Tooltips et `aria-label` pertinents sur les boutons icônes seuls ; états focus visibles.
- Contrôles de tri, recherche, drawer et filtres ne doivent jamais déclencher une sauvegarde involontaire.

## 10. Exclusions

Ne pas ramener les gros blocs « fabrication », « suivi qualité », « devis et révisions », anciennes explications, ou catalogue permanent de services dans l'écran central. Le périmètre est l'écran de saisie et son drawer d'affectation.

## 11. Livraison attendue de Codex

- Inventaire du point d'entrée existant, des DocTypes/API/champs, et des contraintes identifiées.
- Modification du composant réel (pas de maquette parallèle hors application).
- Tests unitaires / d'interaction ciblant les règles de sélection et d'affectation, plus tests de persistance adaptés.
- Capture écran finale à comparer à la PNG fournie ; tolérer la présence/absence conditionnelle des scrollbars selon le volume.
- Liste des fichiers modifiés, commandes de build/test et éventuels écarts non résolus.
