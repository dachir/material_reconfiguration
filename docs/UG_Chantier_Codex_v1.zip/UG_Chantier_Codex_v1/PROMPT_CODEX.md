# Prompt à transmettre à Codex

Reprends l'écran **Chantier** existant d'**Univers Glass** dans le dépôt Frappe/ERPNext `mat_reco` en suivant strictement l'image `assets/chantier_reference_validee.png` comme référence de layout, et `SPECIFICATION_ECRAN_CHANTIER.md` comme contrat fonctionnel. Consulte également `RECETTE.md`.

**Important :** Il s'agit d'implémenter l'écran réel, pas de créer une simple maquette autonome. Commence par inspecter le dépôt pour identifier le frontend, les endpoints, DocTypes, Child Tables, champs et règles métier utilisés par la page Chantier ; présente une correspondance avant modification. Réutilise les API et workflows existants, sans inventer de modèle.

Points obligatoires :
1. En-tête compact sur 2 colonnes.
2. Panneau Sections à gauche repliable ; largeur récupérée par la grille.
3. Grille tabulaire à saisie continue façon Frappe, sans numéros de ligne : remplacer par chevrons pour consulter les prestations sous l'ouvrage.
4. Scroll vertical et horizontal conditionnels dans la grille.
5. Icon button Prestations **sur chaque ligne** : ouvre un **drawer droit**, jamais une modale.
6. S'il existe des cases ouvrages cochées, l'icône de **n'importe quelle ligne** cible seulement les ouvrages cochés, même si l'icône cliquée appartient à une ligne non cochée. En l'absence de sélection, elle cible uniquement la ligne cliquée.
7. Les prestations peuvent être sélectionnées en masse dans le drawer, puis affectées à toutes les cibles sans doublons indus.
8. Préserver l'enregistrement Frappe, les validations, les permissions, les règles de calcul et le processus chantier → étude technique → devis → commande → fabrication.

Implémente, ajoute ou adapte des tests, lance build/tests, puis fournis une capture du résultat et la liste exacte des fichiers modifiés. Si une règle n'est pas déductible du code, ne la remplace pas : indique clairement le point bloquant et propose une hypothèse à valider.
