# Univers Glass — Reprise de l'écran Chantier (VueJS / Frappe)

**Date :** 17 octobre 2026  
**Livrable :** dossier de transmission pour Codex  
**Statut :** maquette UX validée par le demandeur

## Contenu

- `assets/chantier_reference_validee.png` — **image de référence fournie par le demandeur**, à reproduire visuellement.
- `SPECIFICATION_ECRAN_CHANTIER.md` — dispositions, workflows, états, contraintes, exigences d'intégration.
- `RECETTE.md` — scénarios vérifiables d'acceptation.
- `PROMPT_CODEX.md` — consigne directement réutilisable dans Codex.

## Priorité des sources

1. Conserver les schémas, validations, permissions, API et workflows du dépôt **réel** `mat_reco`.
2. Utiliser l'image jointe comme référence de composition, de thème et d'ergonomie.
3. Utiliser la spécification comme contrat des interactions non visibles dans l'image.
4. Ne pas interpréter les valeurs affichées dans la maquette comme des données réelles ou des prix garantis.

## Important

Le ZIP n'est **pas une implémentation** ni un fork de `mat_reco`. Il est volontairement léger pour être attaché au dépôt existant sans en écraser le contenu.

Une archive `mat_reco.zip` a été consultée à titre de repérage : elle contient notamment `frontend/mcp-ux20-vue/` et `frontend/workshop-vue/`. Aucun chemin de composant Chantier n'a été confirmé par cette vérification des noms de fichiers. Codex doit découvrir l'implémentation effective, sans présumer que ces deux frontends hébergent nécessairement l'écran Chantier.
