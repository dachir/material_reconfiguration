# Recette — Chantier Univers Glass

| ID | Test | Attendu |
|---|---|---|
| CH-01 | Ouvrir chantier existant | En-tête et ouvrages chargés avec données réelles |
| CH-02 | Créer ouvrage et naviguer au clavier | Saisie continue en cellule, sans modale |
| CH-03 | Modifier dimensions/quantité | Valeurs validées et montants cohérents avec serveur |
| CH-04 | Cliquer + ligne dans section Façade | La nouvelle ligne hérite de Façade |
| CH-05 | Replier Sections | La grille s'élargit sans perte de sélection/édition |
| CH-06 | Ouvrir/fermer chevron d'une ligne | Détail prestations sous cette ligne uniquement |
| CH-07 | Dépasser la hauteur de la grille | Scroll vertical indépendant du formulaire |
| CH-08 | Réduire la largeur utile | Scroll horizontal pour atteindre les colonnes |
| CH-09 | Aucune case cochée, clic icône A | Drawer cible A exclusivement |
| CH-10 | Cocher A+B puis clic icône C | Drawer cible A+B et jamais C |
| CH-11 | Cocher A+B puis clic icône B | Drawer cible A+B |
| CH-12 | Filtrer section avec sélection masquée | Compteur / cible intègrent la sélection réelle |
| CH-13 | Sélectionner 2 prestations, affecter A+B | Chaque destinataire reçoit les 2 prestations |
| CH-14 | Refaire exactement la même affectation | Aucun doublon indu |
| CH-15 | Fermer drawer sans valider | Pas d'affectation nouvelle |
| CH-16 | Après affectation | Sélection ouvrages conservée ; détails synchronisés |
| CH-17 | Filtrer prestations en ayant coché des entrées | Les choix ne disparaissent pas silencieusement |
| CH-18 | Enregistrer puis recharger | Données sauvegardées et conformes aux DocTypes |
| CH-19 | Validation ou permission serveur refuse | Message utile, pas de perte silencieuse des éditions |
| CH-20 | Chantier avec centaines de lignes | Navigation/édition/scroll fluides |
| CH-21 | Compare capture UI | Mise en page sombre, Sections, grille, drawer droit proches du PNG validé |

## Priorité de recette

Les tests **CH-09 à CH-16** sont bloquants : ils protègent la règle d'affectation groupée décidée par le métier. Les tests **CH-02, CH-06, CH-07, CH-08** protègent le standard de saisie continue.
