# Package à transmettre à Codex

**Document maître** : `MEMO_CODEX.md`.

**Fichiers de référence :**
- `assets/maquette_validee_sans_menu.png` : capture approuvée, référence prioritaire pour UI/UX.
- `assets/vitres_header_extrait_reference.png` : extraction du décor de vitres du coin supérieur droit (petite image de référence ; contient son fond sombre).
- `assets/vitres_header_overlay.png` : même extraction, contours fondus transparents, à positionner en superposition d'en-tête.

**À savoir :** le décor est extrait de la capture validée, non le fichier source original haute résolution de la photo ; si l'asset paraît trop petit à l'affichage, recréer une illustration dans le même style ou retrouver la ressource d'origine, sans changer le design validé.

**Prompt rapide Codex :** « Implémente la fonctionnalité Stock Verre — Volumes & Chutes dans mat_reco conformément à `MEMO_CODEX.md`, avec la capture et les assets fournis. Commence par inspecter le modèle de stock et de filiation réel, puis réalise l'API Frappe, la vue Vue 3, et les tests. »
