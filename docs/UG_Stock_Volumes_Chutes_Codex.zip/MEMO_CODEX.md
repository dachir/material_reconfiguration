# MÉMO DE RÉALISATION — UG Stock Verre : Volumes & Chutes
**Projet :** Univers Glass / `mat_reco` · **Date :** 16 octobre 2026 · **Statut :** maquette UI validée par le métier

## 0. Mandat
Implémenter dans l’application Frappe/ERPNext `mat_reco` un écran **Vue 3** « État des stocks — Volumes & Chutes », en lecture seule, destiné notamment au Directeur général. Reproduire fidèlement la **maquette validée**, `assets/maquette_validee_sans_menu.png`. **Aucun menu latéral à gauche** ; contenu pleine largeur, thème sombre, accents verts. Ne pas réinterpréter visuellement les dispositions sans nécessité technique.

Une capture constitue une **référence visuelle, pas des données de production** : tous les chiffres, entrepôts, descriptions et numéros de série affichés sont fictifs. Aucune donnée codée en dur dans le produit final.

## 1. Livrables demandés à Codex
1. Page Vue 3 responsive intégrée à `mat_reco`, assets servis localement, interface en français (libellé `Warehouse` conservé à l'écran conformément à la maquette).
2. API(s) Python Frappe sécurisées pour le récapitulatif, les filtres, la pagination/liste des pièces et éventuellement l'export.
3. Tests unitaires / intégration couvrant agrégats, filtrage Warehouse, série en stock, surface, permissions et pagination.
4. Documentation courte : route d'accès, commande de build, sources de données, configuration et éventuelles migrations.
5. Vérification visuelle sur desktop et écran étroit, avec capture comparée à la référence.

## 2. Identité visuelle et placement exact
- **Pleine largeur** : supprimer entièrement la sidebar gauche, ne pas réserver de marge de navigation.
- En-tête : breadcrumb `UNIVERS GLASS / INVENTAIRE`; titre `État des stocks — Volumes & Chutes`; sous-titre `Temps réel` ; décor **vitres en haut à droite**, à intégrer via `assets/vitres_header_overlay.png` ou `assets/vitres_header_extrait_reference.png`, avec `background-size: cover`/positionnement adapté, sans étirer l’image. La photographie est extraite de la référence approuvée : le premier PNG est une découpe fidèle, le second a des bordures transparentes progressives pour superposition.
- Le slogan à droite du bandeau est du **texte HTML**, et non une partie de l'image, pour rester lisible. Ne pas utiliser d’image entière de la maquette comme arrière-plan interactif.
- Barre filtres, de gauche à droite : recherche `Item / N° série`, filtre **Warehouse** (défaut `Tous`), indicateur d'actualisation en direct, bouton de rafraîchissement manuel, horodatage de dernière mise à jour.
- Trois KPI sur une rangée : `Volumes`, `Chutes`, `Surface disponible` (m²). Les KPI respectent les filtres, notamment Warehouse.
- Table sombre compacte avec colonnes **`Item / N° série | Dimensions (mm) | Qté | m² | Warehouse`**. Les parent rows représentent les familles d'Item primaire avec décompte `N volumes · N chutes`. Les enfants représentent **une pièce physique par Serial No**, **sans badge ni mot « Découpe »**. Une ligne = numéro de série, dimensions (L × l × épaisseur), `Qté = 1`, surface en m², warehouse effectif.
- Parent cliquable pour développer/rabattre ; ouverture paresseuse. Ligne enfant sélectionnée : surlignage vert foncé, sélection mono-ligne. Hauteur cible enfant **28–30 px** ; entête fixe, corps scrollable ; scrollbar discrète ; totaux et nombre de lignes en pied. Ne pas imposer des cartes par chute.
- Respecter les proportions, marges, tailles, couleurs et alignements de la maquette. Dans l’application, l'horodatage vient du serveur, non d'une valeur figée.

## 3. Sens des termes (interface vs technique)
| Libellé écran | Sens métier | Donnée technique potentielle |
|---|---|---|
| Volumes | Plaques de verre **entières**, physiquement en stock | Serial No marqué `Full` **si** cette règle reste exacte dans le modèle |
| Chutes | Pièces découpées / résidus de verre en stock | `Partial` et autres résultats de découpe, selon modèle réellement observé |
| Surface disponible | Surface du stock réellement libre/utilisable | somme de surfaces des Serial No éligibles, pas une simple multiplication globale |
| Warehouse | Emplacement réel de chaque unité physique | Warehouse courant déterminé par le ledger / mécanisme série ERPNext |

**Important :** les codes et champs ERPNext existants (`PRIMAIRE`, `Full`, `Partial`...) restent inchangés. Le libellé « Volumes » ne désigne pas des m³. Ne jamais convertir aveuglément tous les `Full` en volumes ou tous les `Partial` en chutes avant validation des cas réels : une découpe devenue un Item distinct peut ne pas hériter d'un statut `Partial`.

## 4. Logique de regroupement
- La racine de chaque groupe est un **Item de type `PRIMAIRE`** (`Item.custom_item_types`, à confirmer dans le dépôt et les fixtures).
- Dans ce groupe : quantités agrégées `volumes`, `chutes`, `total`, `surface_m2`, puis lignes de Serial No courants rattachés au primaire.
- Les filières parent/enfant peuvent passer par Material Cutting Plan, Material Reconfiguration, Item variants ou autres liens. **Identifier et utiliser la relation de filiation réellement persistée dans `mat_reco` ; ne pas deviner par le nom du Serial No ou la similarité d’un Item.** Si l'information est absente, produire un diagnostic explicite et une stratégie de correction/ajout minimal (sans migration destructive).
- Un même Serial No ne doit jamais être compté deux fois même si plusieurs historiques de transformations le mentionnent.
- Le Warehouse de la ligne parent est `—` quand plusieurs warehouses sont concernés ; pour un Warehouse filtré, les résultats et KPI reflètent uniquement ce Warehouse.
- Stock physique et stock **disponible** diffèrent potentiellement en cas de réservation. Ne pas prétendre que « disponible » signifie non réservé sans source fiable. Prévoir le détail `physical / reserved / available` si les réservations sont accessibles ; sinon documenter précisément la limite et renommer ou qualifier l'indicateur.

## 5. Source de vérité ERPNext
- Récupérer les Serial No **effectivement en stock**, via les mécanismes d'inventaire de la version ERPNext installée (Serial and Batch Bundle, Stock Ledger Entry / informations de dépôt pertinentes) ; exclure les séries sorties/consommées/annulées. Prendre en compte les mouvements soumis et leurs annulations.
- Vérifier `docstatus` et cohérence avec stocks ERPNext, sans mélanger draft, historique et stock réel.
- Les dimensions viennent des champs de Serial No existants, notamment `custom_dimension_length_mm`, `custom_dimension_width_mm`, `custom_dimension_thickness_mm` lorsque présents ; vérifier les unités.
- Pour rectangle : `surface_m2 = L_mm × l_mm / 1_000_000`. Pour chute **en L**, utiliser impérativement la géométrie sauvegardée / le calcul géométrique déjà existant (ex. `single_geometry.single_area`) et non le rectangle englobant. Tester les géométries invalides / dimensions manquantes. Surface des lignes affichée avec arrondi, somme calculée sur valeurs non arrondies.
- Source candidate utile à **examiner**, pas à réutiliser aveuglément : `mat_reco/material_reconfiguration/services/stock_candidate_service.py` (`get_available_cutting_bins`) : ce service filtre des candidats de découpe, il n'est pas forcément un inventaire général exhaustif.
- Les chaînes de noms de Warehouse sont propres à chaque site ; récupérer les options autorisées via ERPNext, ne pas figer `Magasin Principal` ou `Atelier Coupe`.

## 6. API et performances
Proposition de contrats API (noms à adapter aux conventions du dépôt) :
- `get_stock_overview(search?, warehouse?)` → `{as_of, volumes, chutes, surface_m2, groups:[{item_code,item_name,volumes,chutes,total,surface_m2,...}]}` avec **agrégats calculés côté serveur**.
- `get_stock_serials(item_code, warehouse?, search?, cursor?, page_size?)` → `{rows:[{serial_no,item_code,length_mm,width_mm,thickness_mm,area_m2,warehouse,classification}], next_cursor, total}`.
- `get_warehouses()` → uniquement warehouses accessibles à l'utilisateur courant.
- Au-delà de quelques centaines de chutes : **pagination serveur et virtualisation**, pas de rendu simultané de milliers de lignes ; chargement à l'expansion. Recherche par Item ET Serial No, y compris séries non encore chargées en client.
- Rafraîchissement via événements `frappe.realtime` **après commit / événement fiable**, avec réinterrogation serveur ciblée et anti-rebond ; `actualiser` manuel et rafraîchissement de secours à intervalle raisonnable. Ne pas prétendre que Socket.IO garantit à lui seul une cohérence de stock transactionnelle.
- Permissions : contrôler les rôles et permissions sur Item, Serial No, Warehouse et détails de stocks côté API ; éviter toute exposition de stock d'entrepôts non autorisés. Gestion de l'absence de droits, de chargement, erreur API et état vide.
- Tests de volumétrie indicatifs : ≥ 10 000 numéros de série, groupes nombreux, changement rapide de Warehouse ; définir un seuil de latence mesurable dans le rapport de tests plutôt que promettre une performance sans mesures.

## 7. Critères d'acceptation
1. La page correspond à `maquette_validee_sans_menu.png` **sans sidebar**, bandeau vitres en haut à droite visible, taille du tableau compacte.
2. `Warehouse: Tous` voit tous les warehouses autorisés ; sélectionner un Warehouse actualise lignes, agrégats et KPI sans incohérence.
3. Chaque famille primaire a son groupe pliable, avec `N volumes · N chutes` ; les centaines de lignes enfant n'affichent **aucun** libellé « Découpe ».
4. Chaque ligne de série contient **Serial No, dimensions, quantité 1, m², Warehouse** ; sélection verdâtre.
5. La somme des groupes correspond au stock physique réel dans ERPNext sur échantillon vérifié (avec sorties, transferts, découpes, recomposition, séries annulées).
6. Les chutes en L et les séries n'ayant pas des dimensions rectangulaires simples sont gérées sans surévaluer les surfaces.
7. Aucune API ne renvoie d'information sur un Warehouse non autorisé ; volumes élevés utilisables sans gel de navigateur.
8. Une mise à jour d'inventaire soumise produit une actualisation cohérente de l'écran ; horodatage visible.
9. L'écran est **lecture seule** ; aucune action de mutation de stock.

## 8. Ordre de travail conseillé
(1) Auditer les sources réelles et la filiation Serial No→primaire ; (2) écrire tests d'invariants stock ; (3) implémenter API et permissions ; (4) construire Vue 3 avec l'asset ; (5) brancher rafraîchissement ; (6) confronter sur stock réel, produire captures et résultats tests.

**Instruction finale à Codex :** la capture et ce mémo sont le contrat fonctionnel. Ne pas remplacer la maquette par un autre design ; ne pas transformer les lignes en cartes et ne pas réintroduire le menu latéral.
